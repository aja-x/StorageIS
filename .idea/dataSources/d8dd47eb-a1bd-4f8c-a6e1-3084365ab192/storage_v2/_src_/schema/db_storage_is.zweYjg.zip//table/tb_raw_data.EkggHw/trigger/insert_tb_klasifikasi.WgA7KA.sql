create definer = yuuki@localhost trigger insert_tb_klasifikasi
    before INSERT
    on tb_raw_data
    for each row
BEGIN
    INSERT INTO tb_klasifikasi (
        tb_klasifikasi.asal_beras,
        tb_klasifikasi.jenis,
        tb_klasifikasi.kualitas,
        tb_klasifikasi.berat,
        tb_klasifikasi.jumlah_karung,
        tb_klasifikasi.tanggal_masuk,
        tb_klasifikasi.tanggal_keluar,
        tb_klasifikasi.lokasi,
        tb_klasifikasi.jalur_terdekat
    ) VALUES (
    	(SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(NEW.raw_data, '\r\n', 1), '\r\n', -1)),
        (SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(NEW.raw_data, '\r\n', 2), '\r\n', -1)),
        (SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(NEW.raw_data, '\r\n', 3), '\r\n', -1)),
        (SELECT CONVERT(SUBSTRING_INDEX(SUBSTRING_INDEX(NEW.raw_data, '\r\n', 4), '\r\n', -1), SIGNED)),
        (SELECT CONVERT(SUBSTRING_INDEX(SUBSTRING_INDEX(NEW.raw_data, '\r\n', 5), '\r\n', -1), SIGNED)),
        (SELECT CONVERT(SUBSTRING_INDEX(SUBSTRING_INDEX(NEW.raw_data, '\r\n', 6), '\r\n', -1), DATE)),
        (SELECT CONVERT(SUBSTRING_INDEX(SUBSTRING_INDEX(NEW.raw_data, '\r\n', 7), '\r\n', -1), DATE)),
        (SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(NEW.raw_data, '\r\n', 8), '\r\n', -1)),
        (SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(NEW.raw_data, '\r\n', 9), '\r\n', -1))
    );
END;

